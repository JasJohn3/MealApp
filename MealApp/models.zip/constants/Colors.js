export default
{
    primaryColor: '#f4511e',
    accentColor: '#b1b1b1'
};