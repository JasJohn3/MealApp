class Category{
    //constructor for the class
    constructor(id, title, color){
        //this stores the values as a property
        this.id = id;
        this.title = title;
        this.color = color;
    }
}

export default Category;